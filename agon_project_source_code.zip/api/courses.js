import supabase from './_supabase.js';
import { requireAuth } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const user = requireAuth(req, res, ['admin', 'teacher']);
  if (!user) return;

  try {
    if (req.method === 'GET') {
      const { search = '', page = '1', limit = '10' } = req.query;
      let query = supabase.from('courses').select('*').order('id', { ascending: true });
      if (search) query = query.ilike('name', `%${search}%`);
      const from = (Number(page) - 1) * Number(limit);
      const to = from + Number(limit) - 1;
      const { data, error } = await query.range(from, to);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      if (user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
      const { name, code, teacher_id, class_level, credits } = req.body;
      if (!name || !code) return res.status(400).json({ error: 'Course name and code required' });
      const { data, error } = await supabase
        .from('courses')
        .insert({ name, code, teacher_id: teacher_id || null, class_level, credits })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      if (user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
      const { id, ...payload } = req.body;
      const { data, error } = await supabase.from('courses').update(payload).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      if (user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
      const { id } = req.body;
      const { error } = await supabase.from('courses').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
