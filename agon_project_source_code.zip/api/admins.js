import crypto from 'crypto';
import supabase from './_supabase.js';
import { requireAuth, hashPassword } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const user = requireAuth(req, res, ['admin']);
  if (!user) return;

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('users')
        .select('id, full_name, email, role')
        .eq('role', 'admin')
        .order('id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { full_name, email, password } = req.body;
      if (!full_name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
      const salt = crypto.randomBytes(16).toString('hex');
      const password_hash = hashPassword(password, salt);
      const { data, error } = await supabase
        .from('users')
        .insert({ full_name, email, role: 'admin', password_hash, salt })
        .select('id, full_name, email, role')
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'Missing id' });
      if (Number(id) === Number(user.sub)) {
        return res.status(400).json({ error: 'Cannot remove current admin session' });
      }
      const { error } = await supabase.from('users').delete().eq('id', id).eq('role', 'admin');
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
