import supabase from './_supabase.js';
import { requireAuth } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const user = requireAuth(req, res, ['admin', 'teacher', 'student']);
  if (!user) return;

  try {
    let studentFilter = {};
    if (user.role === 'student') {
      const { data: student } = await supabase
        .from('students')
        .select('id')
        .eq('user_id', user.sub)
        .single();
      if (student) studentFilter = { student_id: student.id };
    }

    const { count: studentsCount } = await supabase.from('students').select('*', { count: 'exact', head: true });
    const { count: teachersCount } = await supabase.from('teachers').select('*', { count: 'exact', head: true });
    const { count: coursesCount } = await supabase.from('courses').select('*', { count: 'exact', head: true });
    const { data: feesData } = await supabase.from('fees').select('*');
    const { data: attendanceData } = await supabase
      .from('attendance')
      .select('*')
      .match(studentFilter);

    const feeTotal = (feesData || []).reduce((sum, fee) => sum + Number(fee.amount || 0), 0);
    const attendanceTotal = (attendanceData || []).length;
    const attendancePresent = (attendanceData || []).filter((a) => a.status === 'Present').length;

    return res.status(200).json({
      students: studentsCount || 0,
      teachers: teachersCount || 0,
      courses: coursesCount || 0,
      fee_total: feeTotal,
      attendance_rate: attendanceTotal ? Math.round((attendancePresent / attendanceTotal) * 100) : 0,
    });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
