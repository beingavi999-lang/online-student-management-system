import supabase from './_supabase.js';
import { requireAuth } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const user = requireAuth(req, res, ['admin', 'student']);
  if (!user) return;

  try {
    if (req.method === 'GET') {
      const { search = '' } = req.query;
      let query = supabase.from('fees').select('*').order('due_date', { ascending: false });
      if (search) query = query.ilike('status', `%${search}%`);
      if (user.role === 'student') {
        const { data: student } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', user.sub)
          .single();
        if (student) query = query.eq('student_id', student.id);
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      if (user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
      const { student_id, amount, status, due_date, paid_date, method } = req.body;
      if (!student_id || !amount) return res.status(400).json({ error: 'Student and amount required' });
      const { data, error } = await supabase
        .from('fees')
        .insert({ student_id, amount, status, due_date, paid_date, method })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      if (user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
      const { id, status, paid_date } = req.body;
      const { data, error } = await supabase.from('fees').update({ status, paid_date }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
