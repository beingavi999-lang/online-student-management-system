import supabase from './_supabase.js';
import { requireAuth } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const user = requireAuth(req, res, ['admin', 'teacher', 'student']);
  if (!user) return;

  try {
    if (req.method === 'GET') {
      let query = supabase.from('documents').select('*').order('uploaded_at', { ascending: false });
      if (user.role === 'student') {
        const { data: student } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', user.sub)
          .single();
        if (student) query = query.eq('student_id', student.id);
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { student_id, title, file_url } = req.body;
      if (!student_id || !title || !file_url) return res.status(400).json({ error: 'Missing fields' });
      const { data, error } = await supabase
        .from('documents')
        .insert({ student_id, title, file_url, uploaded_at: new Date().toISOString() })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
