import supabase from './_supabase.js';
import { createToken, verifyPassword, requireAuth } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const payload = requireAuth(req, res);
      if (!payload) return;
      return res.status(200).json({ user: { id: payload.sub, role: payload.role, email: payload.email, full_name: payload.name } });
    }

    if (req.method === 'POST') {
      const { email, password } = req.body;
      if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .single();
      if (error || !data) return res.status(401).json({ error: 'Invalid credentials' });
      if (!verifyPassword(password, data.salt, data.password_hash)) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      const token = createToken(data);
      return res.status(200).json({
        token,
        user: { id: data.id, email: data.email, role: data.role, full_name: data.full_name },
      });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
