import supabase from './_supabase.js';
import { requireAuth } from './_auth.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const user = requireAuth(req, res, ['admin', 'teacher', 'student']);
  if (!user) return;

  try {
    if (req.method === 'GET') {
      const { status = '' } = req.query;
      let query = supabase.from('attendance').select('*').order('date', { ascending: false });
      if (status) query = query.eq('status', status);
      if (user.role === 'student') {
        const { data: student } = await supabase
          .from('students')
          .select('id')
          .eq('user_id', user.sub)
          .single();
        if (student) query = query.eq('student_id', student.id);
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      if (user.role === 'student') return res.status(403).json({ error: 'Forbidden' });
      const { student_id, course_id, date, status } = req.body;
      if (!student_id || !course_id) return res.status(400).json({ error: 'Student and course required' });
      const { data, error } = await supabase
        .from('attendance')
        .insert({ student_id, course_id, date, status, recorded_by: user.sub })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      if (user.role === 'student') return res.status(403).json({ error: 'Forbidden' });
      const { id, status } = req.body;
      const { data, error } = await supabase.from('attendance').update({ status }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
