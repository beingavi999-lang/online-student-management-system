import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface DocumentsProps {
  token: string;
  user: any;
}

const emptyForm = {
  student_id: '',
  title: '',
  file_url: '',
};

export default function Documents({ token, user }: DocumentsProps) {
  const [documents, setDocuments] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ ...emptyForm });
  const [error, setError] = useState('');

  const fetchDocuments = async () => {
    setLoading(true);
    try {
      const [docData, studentData] = await Promise.all([
        apiFetch<any[]>('/api/documents', {}, token),
        apiFetch<any[]>('/api/students', {}, token),
      ]);
      setDocuments(docData);
      setStudents(studentData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const handleFile = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setForm((prev) => ({ ...prev, file_url: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.student_id || !form.title || !form.file_url) {
      setError('Student, title, and file are required.');
      return;
    }
    try {
      await apiFetch('/api/documents', { method: 'POST', body: JSON.stringify(form) }, token);
      setForm({ ...emptyForm });
      fetchDocuments();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Documents" subtitle="Upload student IDs, certificates, and reports." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="grid gap-4 md:grid-cols-2">
          {documents.map((doc) => (
            <div key={doc.id} className="rounded-2xl border border-slate-200 p-4">
              <p className="text-xs uppercase text-slate-400">{doc.title}</p>
              <p className="text-sm font-semibold text-slate-900">{students.find((s) => s.id === doc.student_id)?.full_name}</p>
              <a
                className="mt-3 inline-flex rounded-lg border border-indigo-200 px-3 py-1 text-xs font-semibold text-indigo-600"
                href={doc.file_url}
                download
              >
                Download File
              </a>
            </div>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-slate-900">Upload new document</h3>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <select
            className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
            value={form.student_id}
            onChange={(e) => setForm({ ...form, student_id: e.target.value })}
          >
            <option value="">Select student</option>
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.full_name}
              </option>
            ))}
          </select>
          <input
            className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Document title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
          />
          <input type="file" onChange={(e) => handleFile(e.target.files?.[0])} />
        </div>
        {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
        <button type="submit" className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">
          Upload document
        </button>
      </form>
    </div>
  );
}
