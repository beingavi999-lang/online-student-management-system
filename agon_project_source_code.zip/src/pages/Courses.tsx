import { useEffect, useState } from 'react';
import { apiFetch, buildQuery } from '../lib/api';
import { exportToCsv } from '../lib/export';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface CoursesProps {
  token: string;
  user: any;
}

const emptyForm = {
  name: '',
  code: '',
  teacher_id: '',
  class_level: '',
  credits: '',
};

export default function Courses({ token, user }: CoursesProps) {
  const [courses, setCourses] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [form, setForm] = useState({ ...emptyForm });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState('');

  const fetchCourses = async () => {
    setLoading(true);
    try {
      const [courseData, teacherData] = await Promise.all([
        apiFetch<any[]>(`/api/courses${buildQuery({ search, page, limit: 6 })}`, {}, token),
        apiFetch<any[]>('/api/teachers', {}, token),
      ]);
      setCourses(courseData);
      setTeachers(teacherData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCourses();
  }, [search, page]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.name || !form.code) {
      setError('Course name and code are required.');
      return;
    }
    try {
      const payload = { ...form, credits: Number(form.credits || 0) };
      if (editingId) {
        await apiFetch('/api/courses', { method: 'PUT', body: JSON.stringify({ id: editingId, ...payload }) }, token);
      } else {
        await apiFetch('/api/courses', { method: 'POST', body: JSON.stringify(payload) }, token);
      }
      setForm({ ...emptyForm });
      setEditingId(null);
      fetchCourses();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleEdit = (course: any) => {
    setEditingId(course.id);
    setForm({
      name: course.name || '',
      code: course.code || '',
      teacher_id: course.teacher_id || '',
      class_level: course.class_level || '',
      credits: course.credits || '',
    });
  };

  const handleDelete = async (id: number) => {
    await apiFetch('/api/courses', { method: 'DELETE', body: JSON.stringify({ id }) }, token);
    fetchCourses();
  };

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Courses & Classes" subtitle="Define subjects, instructors, and class assignments." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <input
            className="w-full max-w-sm rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Search courses"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => exportToCsv('courses.csv', courses)}
            >
              Export CSV
            </button>
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => window.print()}
            >
              Export PDF
            </button>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Course</th>
                <th>Class</th>
                <th>Teacher</th>
                <th>Credits</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {courses.map((course) => (
                <tr key={course.id} className="border-t border-slate-100">
                  <td className="py-3">
                    <p className="font-semibold text-slate-900">{course.name}</p>
                    <p className="text-xs text-slate-500">{course.code}</p>
                  </td>
                  <td>{course.class_level}</td>
                  <td>{teachers.find((teacher) => teacher.id === course.teacher_id)?.full_name || 'Unassigned'}</td>
                  <td>{course.credits}</td>
                  <td className="text-right">
                    {user.role === 'admin' ? (
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEdit(course)}
                          className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-semibold"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(course.id)}
                          className="rounded-lg border border-rose-200 px-3 py-1 text-xs font-semibold text-rose-600"
                        >
                          Delete
                        </button>
                      </div>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <button
            className="rounded-xl border border-slate-200 px-3 py-1 text-xs"
            disabled={page === 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            Previous
          </button>
          <span className="text-xs text-slate-500">Page {page}</span>
          <button
            className="rounded-xl border border-slate-200 px-3 py-1 text-xs"
            disabled={courses.length < 6}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </button>
        </div>
      </div>

      {user.role === 'admin' && (
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900">{editingId ? 'Update course' : 'Add new course'}</h3>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Course name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Course code"
              value={form.code}
              onChange={(e) => setForm({ ...form, code: e.target.value })}
            />
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.teacher_id}
              onChange={(e) => setForm({ ...form, teacher_id: e.target.value })}
            >
              <option value="">Assign teacher</option>
              {teachers.map((teacher) => (
                <option key={teacher.id} value={teacher.id}>
                  {teacher.full_name}
                </option>
              ))}
            </select>
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Class Level"
              value={form.class_level}
              onChange={(e) => setForm({ ...form, class_level: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Credits"
              value={form.credits}
              onChange={(e) => setForm({ ...form, credits: e.target.value })}
            />
          </div>
          {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
          <div className="mt-4 flex gap-2">
            <button
              type="submit"
              className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white"
            >
              {editingId ? 'Save changes' : 'Add course'}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm({ ...emptyForm });
                }}
                className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
}
