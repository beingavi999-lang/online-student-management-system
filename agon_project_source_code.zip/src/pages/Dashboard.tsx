import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../lib/api';
import Loading from '../components/Loading';
import StatCard from '../components/StatCard';
import Topbar from '../components/Topbar';

interface DashboardProps {
  token: string;
  user: any;
}

export default function Dashboard({ token, user }: DashboardProps) {
  const [summary, setSummary] = useState<any>(null);
  const [attendance, setAttendance] = useState<any[]>([]);
  const [fees, setFees] = useState<any[]>([]);
  const [marks, setMarks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [summaryData, attendanceData, feeData, markData] = await Promise.all([
        apiFetch<any>('/api/summary', {}, token),
        apiFetch<any[]>('/api/attendance', {}, token),
        apiFetch<any[]>('/api/fees', {}, token),
        apiFetch<any[]>('/api/marks', {}, token),
      ]);
      setSummary(summaryData);
      setAttendance(attendanceData);
      setFees(feeData);
      setMarks(markData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const attendanceStats = useMemo(() => {
    const total = attendance.length;
    const present = attendance.filter((a) => a.status === 'Present').length;
    const late = attendance.filter((a) => a.status === 'Late').length;
    const absent = attendance.filter((a) => a.status === 'Absent').length;
    return { total, present, late, absent, rate: total ? Math.round((present / total) * 100) : 0 };
  }, [attendance]);

  const feeStats = useMemo(() => {
    const total = fees.reduce((sum, fee) => sum + Number(fee.amount || 0), 0);
    const paid = fees.filter((fee) => fee.status === 'Paid').reduce((sum, fee) => sum + Number(fee.amount || 0), 0);
    return { total, paid, pending: total - paid };
  }, [fees]);

  const performance = useMemo(() => {
    if (marks.length === 0) return { average: 0, label: 'Awaiting data', message: 'Add marks to generate AI insights.' };
    const totalScore = marks.reduce((sum, mark) => sum + Number(mark.score || 0), 0);
    const totalMax = marks.reduce((sum, mark) => sum + Number(mark.max_score || 0), 0);
    const average = totalMax ? (totalScore / totalMax) * 100 : 0;
    const attendanceRate = attendanceStats.rate;
    let label = 'Good Standing';
    let message = 'Maintain consistency to stay on track.';
    if (average >= 85 && attendanceRate >= 90) {
      label = 'Excellent';
      message = 'High achievement and stellar attendance. Ready for honors.';
    } else if (average >= 70) {
      label = 'Growth Potential';
      message = 'Scores are solid. Encourage focused revision and practice.';
    } else {
      label = 'At Risk';
      message = 'Intervene with mentoring and additional tutoring.';
    }
    return { average: Math.round(average), label, message };
  }, [marks, attendanceStats.rate]);

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Dashboard" subtitle="Overview of academic operations and analytics." />
      <div className="grid gap-4 lg:grid-cols-4">
        <StatCard label="Total Students" value={summary?.students || 0} tone="blue" />
        <StatCard label="Total Teachers" value={summary?.teachers || 0} tone="emerald" />
        <StatCard label="Active Courses" value={summary?.courses || 0} tone="amber" />
        <StatCard label="Attendance Rate" value={`${attendanceStats.rate}%`} tone="purple" />
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[2fr_1fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Attendance Distribution</h2>
          <p className="text-sm text-slate-500">Live classroom engagement across sessions.</p>
          <div className="mt-6 space-y-4">
            {[
              { label: 'Present', value: attendanceStats.present, color: 'bg-emerald-500' },
              { label: 'Late', value: attendanceStats.late, color: 'bg-amber-500' },
              { label: 'Absent', value: attendanceStats.absent, color: 'bg-rose-500' },
            ].map((row) => (
              <div key={row.label}>
                <div className="flex items-center justify-between text-sm text-slate-600">
                  <span>{row.label}</span>
                  <span className="font-semibold text-slate-900">{row.value}</span>
                </div>
                <div className="mt-2 h-2 w-full rounded-full bg-slate-100">
                  <div
                    className={`h-2 rounded-full ${row.color}`}
                    style={{ width: attendanceStats.total ? `${(row.value / attendanceStats.total) * 100}%` : '0%' }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Fee Collection</h2>
          <p className="text-sm text-slate-500">Payment health and outstanding balances.</p>
          <div className="mt-6 space-y-4">
            <div className="rounded-2xl bg-indigo-50 p-4">
              <p className="text-xs uppercase text-indigo-500">Total Due</p>
              <p className="text-2xl font-semibold text-indigo-700">₹{feeStats.total.toFixed(2)}</p>
            </div>
            <div className="flex items-center justify-between text-sm text-slate-600">
              <span>Paid</span>
              <span className="font-semibold text-emerald-600">₹{feeStats.paid.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm text-slate-600">
              <span>Outstanding</span>
              <span className="font-semibold text-rose-500">₹{feeStats.pending.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">AI Performance Prediction</h2>
          <p className="text-sm text-slate-500">Prediction blends marks and attendance consistency.</p>
          <div className="mt-6 flex flex-col gap-4">
            <div className="rounded-2xl bg-slate-50 p-4">
              <p className="text-sm font-semibold text-slate-900">Predicted Status</p>
              <p className="text-2xl font-semibold text-indigo-600">{performance.label}</p>
              <p className="text-sm text-slate-500">{performance.message}</p>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm text-slate-600">
                <span>Average Score</span>
                <span className="font-semibold text-slate-900">{performance.average}%</span>
              </div>
              <div className="mt-2 h-2 w-full rounded-full bg-slate-100">
                <div
                  className="h-2 rounded-full bg-indigo-500"
                  style={{ width: `${performance.average}%` }}
                />
              </div>
            </div>
          </div>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Role-based Focus</h2>
          <p className="text-sm text-slate-500">Key responsibilities tailored for {user.role}.</p>
          <div className="mt-6 space-y-3 text-sm text-slate-600">
            {user.role === 'admin' && (
              <ul className="space-y-2">
                <li>• Monitor institutional KPIs and compliance.</li>
                <li>• Approve enrollments, fees, and staffing updates.</li>
                <li>• Review AI performance flags and action plans.</li>
              </ul>
            )}
            {user.role === 'teacher' && (
              <ul className="space-y-2">
                <li>• Capture attendance in real time.</li>
                <li>• Publish marks with qualitative feedback.</li>
                <li>• Initiate student guardian notifications.</li>
              </ul>
            )}
            {user.role === 'student' && (
              <ul className="space-y-2">
                <li>• Track attendance and daily performance.</li>
                <li>• Review fees and download documents.</li>
                <li>• Act on AI study recommendations.</li>
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
