import { useEffect, useMemo, useState } from 'react';
import { apiFetch, buildQuery } from '../lib/api';
import { exportToCsv } from '../lib/export';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface FeesProps {
  token: string;
  user: any;
}

const emptyForm = {
  student_id: '',
  amount: '',
  status: 'Pending',
  due_date: new Date().toISOString().slice(0, 10),
  method: 'Bank Transfer',
};

export default function Fees({ token, user }: FeesProps) {
  const [fees, setFees] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ ...emptyForm });
  const [error, setError] = useState('');

  const fetchFees = async () => {
    setLoading(true);
    try {
      const [feesData, studentsData] = await Promise.all([
        apiFetch<any[]>(`/api/fees${buildQuery({ search })}`, {}, token),
        apiFetch<any[]>('/api/students', {}, token),
      ]);
      setFees(feesData);
      setStudents(studentsData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFees();
  }, [search]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.student_id || !form.amount) {
      setError('Student and amount are required.');
      return;
    }
    try {
      await apiFetch('/api/fees', { method: 'POST', body: JSON.stringify({
        ...form,
        amount: Number(form.amount || 0),
      }) }, token);
      setForm({ ...emptyForm });
      fetchFees();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleMarkPaid = async (fee: any) => {
    await apiFetch('/api/fees', { method: 'PUT', body: JSON.stringify({ id: fee.id, status: 'Paid', paid_date: new Date().toISOString() }) }, token);
    fetchFees();
  };

  const studentMap = useMemo(() => Object.fromEntries(students.map((s) => [s.id, s.full_name])), [students]);

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Fee Management" subtitle="Invoices, payments, and outstanding balances." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <input
            className="w-full max-w-sm rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Search by status"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => exportToCsv('fees.csv', fees)}
            >
              Export CSV
            </button>
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => window.print()}
            >
              Export PDF
            </button>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Student</th>
                <th>Amount</th>
                <th>Due</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {fees.map((fee) => (
                <tr key={fee.id} className="border-t border-slate-100">
                  <td className="py-3 font-semibold text-slate-900">{studentMap[fee.student_id]}</td>
                  <td>₹{Number(fee.amount).toFixed(2)}</td>
                  <td>{fee.due_date ? new Date(fee.due_date).toLocaleDateString() : '-'}</td>
                  <td>
                    <span
                      className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        fee.status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-700'
                          : fee.status === 'Overdue'
                          ? 'bg-rose-100 text-rose-700'
                          : 'bg-amber-100 text-amber-700'
                      }`}
                    >
                      {fee.status}
                    </span>
                  </td>
                  <td className="text-right">
                    {user.role === 'admin' && fee.status !== 'Paid' && (
                      <button
                        onClick={() => handleMarkPaid(fee)}
                        className="rounded-lg border border-emerald-200 px-3 py-1 text-xs font-semibold text-emerald-600"
                      >
                        Mark Paid
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {user.role === 'admin' && (
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900">Create fee record</h3>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.student_id}
              onChange={(e) => setForm({ ...form, student_id: e.target.value })}
            >
              <option value="">Select student</option>
              {students.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.full_name}
                </option>
              ))}
            </select>
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Amount"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              type="date"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            />
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
            >
              <option value="Pending">Pending</option>
              <option value="Paid">Paid</option>
              <option value="Overdue">Overdue</option>
            </select>
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Payment method"
              value={form.method}
              onChange={(e) => setForm({ ...form, method: e.target.value })}
            />
          </div>
          {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
          <button type="submit" className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">
            Save fee
          </button>
        </form>
      )}
    </div>
  );
}
