import { useEffect, useState } from 'react';
import { apiFetch, buildQuery } from '../lib/api';
import { exportToCsv } from '../lib/export';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface StudentsProps {
  token: string;
  user: any;
}

const emptyForm = {
  full_name: '',
  email: '',
  phone: '',
  class_level: '',
  guardian_name: '',
  photo_url: '',
};

export default function Students({ token, user }: StudentsProps) {
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [form, setForm] = useState({ ...emptyForm });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState('');

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const data = await apiFetch<any[]>(
        `/api/students${buildQuery({ search, page, limit: 6 })}`,
        {},
        token
      );
      setStudents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, [search, page]);

  const handleFile = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setForm((prev) => ({ ...prev, photo_url: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.full_name || !form.class_level) {
      setError('Name and class level are required.');
      return;
    }
    try {
      if (editingId) {
        await apiFetch(`/api/students`, {
          method: 'PUT',
          body: JSON.stringify({ id: editingId, ...form }),
        }, token);
      } else {
        await apiFetch(`/api/students`, {
          method: 'POST',
          body: JSON.stringify(form),
        }, token);
      }
      setForm({ ...emptyForm });
      setEditingId(null);
      fetchStudents();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleEdit = (student: any) => {
    setEditingId(student.id);
    setForm({
      full_name: student.full_name || '',
      email: student.email || '',
      phone: student.phone || '',
      class_level: student.class_level || '',
      guardian_name: student.guardian_name || '',
      photo_url: student.photo_url || '',
    });
  };

  const handleDelete = async (id: number) => {
    await apiFetch('/api/students', { method: 'DELETE', body: JSON.stringify({ id }) }, token);
    fetchStudents();
  };

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Students" subtitle="Manage student profiles, guardians, and documents." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <input
            className="w-full max-w-sm rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Search students"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => exportToCsv('students.csv', students)}
            >
              Export CSV
            </button>
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => window.print()}
            >
              Export PDF
            </button>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Student</th>
                <th>Class</th>
                <th>Guardian</th>
                <th>Contact</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {students.map((student) => (
                <tr key={student.id} className="border-t border-slate-100">
                  <td className="py-3">
                    <div className="flex items-center gap-3">
                      {student.photo_url ? (
                        <img src={student.photo_url} className="h-10 w-10 rounded-full object-cover" />
                      ) : (
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-100 text-sm font-semibold text-indigo-600">
                          {student.full_name?.[0]}
                        </div>
                      )}
                      <div>
                        <p className="font-semibold text-slate-900">{student.full_name}</p>
                        <p className="text-xs text-slate-500">{student.email}</p>
                      </div>
                    </div>
                  </td>
                  <td>{student.class_level}</td>
                  <td>{student.guardian_name}</td>
                  <td className="text-slate-500">{student.phone}</td>
                  <td className="text-right">
                    {user.role === 'admin' ? (
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEdit(student)}
                          className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-semibold"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(student.id)}
                          className="rounded-lg border border-rose-200 px-3 py-1 text-xs font-semibold text-rose-600"
                        >
                          Delete
                        </button>
                      </div>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <button
            className="rounded-xl border border-slate-200 px-3 py-1 text-xs"
            disabled={page === 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            Previous
          </button>
          <span className="text-xs text-slate-500">Page {page}</span>
          <button
            className="rounded-xl border border-slate-200 px-3 py-1 text-xs"
            disabled={students.length < 6}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </button>
        </div>
      </div>

      {user.role === 'admin' && (
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900">{editingId ? 'Update student' : 'Add new student'}</h3>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Full name"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Phone"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Class Level"
              value={form.class_level}
              onChange={(e) => setForm({ ...form, class_level: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Guardian Name"
              value={form.guardian_name}
              onChange={(e) => setForm({ ...form, guardian_name: e.target.value })}
            />
            <div className="flex flex-col gap-2">
              <label className="text-xs text-slate-500">Student Photo (upload)</label>
              <input type="file" accept="image/*" onChange={(e) => handleFile(e.target.files?.[0])} />
            </div>
          </div>
          {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
          <div className="mt-4 flex gap-2">
            <button
              type="submit"
              className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white"
            >
              {editingId ? 'Save changes' : 'Add student'}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm({ ...emptyForm });
                }}
                className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
}
