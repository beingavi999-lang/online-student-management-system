import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface AdminsProps {
  token: string;
}

const emptyForm = {
  full_name: '',
  email: '',
  password: '',
};

export default function Admins({ token }: AdminsProps) {
  const [admins, setAdmins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ ...emptyForm });
  const [error, setError] = useState('');

  const fetchAdmins = async () => {
    setLoading(true);
    try {
      const data = await apiFetch<any[]>('/api/admins', {}, token);
      setAdmins(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdmins();
  }, []);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.full_name || !form.email || !form.password) {
      setError('Name, email, and password are required.');
      return;
    }
    try {
      await apiFetch('/api/admins', { method: 'POST', body: JSON.stringify(form) }, token);
      setForm({ ...emptyForm });
      fetchAdmins();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDelete = async (id: number) => {
    await apiFetch('/api/admins', { method: 'DELETE', body: JSON.stringify({ id }) }, token);
    fetchAdmins();
  };

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Admin Management" subtitle="Create and revoke administrator access." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Admin</th>
                <th>Email</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {admins.map((admin) => (
                <tr key={admin.id} className="border-t border-slate-100">
                  <td className="py-3 font-semibold text-slate-900">{admin.full_name}</td>
                  <td>{admin.email}</td>
                  <td className="text-right">
                    <button
                      onClick={() => handleDelete(admin.id)}
                      className="rounded-lg border border-rose-200 px-3 py-1 text-xs font-semibold text-rose-600"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-slate-900">Add new admin</h3>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <input
            className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Full name"
            value={form.full_name}
            onChange={(e) => setForm({ ...form, full_name: e.target.value })}
          />
          <input
            className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Email"
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
          <input
            className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Temporary password"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
        </div>
        {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
        <button type="submit" className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">
          Create admin
        </button>
      </form>
    </div>
  );
}
