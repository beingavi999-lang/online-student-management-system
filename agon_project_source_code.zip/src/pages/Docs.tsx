import Topbar from '../components/Topbar';

export default function Docs() {
  return (
    <div>
      <Topbar title="Project Documentation" subtitle="Beginner-friendly guide, ER diagram, and deployment steps." />
      <div className="space-y-6">
        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">ER Diagram Summary</h2>
          <p className="mt-2 text-sm text-slate-600">
            The system is centered on <strong>Users</strong> (Admin, Teacher, Student) who authenticate via JWT. Students
            and teachers connect to <strong>Courses</strong>. Attendance, Marks, Fees, Documents, and Results all reference
            students and courses to enforce relational integrity. Admin users manage global configuration and fee policies.
          </p>
          <ul className="mt-4 list-disc space-y-2 pl-6 text-sm text-slate-600">
            <li>Users → Students (1:1 optional) for student portal access.</li>
            <li>Teachers → Courses (1:N) for class assignments.</li>
            <li>Students → Attendance / Marks / Fees / Documents (1:N).</li>
            <li>Courses → Attendance / Marks (1:N).</li>
          </ul>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">REST API Endpoints</h2>
          <div className="mt-3 grid gap-3 text-sm text-slate-600 md:grid-cols-2">
            <div>
              <p className="font-semibold">/api/auth</p>
              <p>POST login, GET current session.</p>
            </div>
            <div>
              <p className="font-semibold">/api/students</p>
              <p>CRUD students with search + pagination.</p>
            </div>
            <div>
              <p className="font-semibold">/api/teachers</p>
              <p>CRUD teachers with role checks.</p>
            </div>
            <div>
              <p className="font-semibold">/api/courses</p>
              <p>CRUD courses and assign instructors.</p>
            </div>
            <div>
              <p className="font-semibold">/api/attendance</p>
              <p>Real-time attendance logs with status updates.</p>
            </div>
            <div>
              <p className="font-semibold">/api/marks</p>
              <p>Record assessments and results.</p>
            </div>
            <div>
              <p className="font-semibold">/api/fees</p>
              <p>Manage invoices, payments, and due dates.</p>
            </div>
            <div>
              <p className="font-semibold">/api/documents</p>
              <p>Upload student documents (base64 stored).</p>
            </div>
            <div>
              <p className="font-semibold">/api/notifications</p>
              <p>Log email/SMS announcements for audit.</p>
            </div>
            <div>
              <p className="font-semibold">/api/summary</p>
              <p>Dashboard analytics summary.</p>
            </div>
            <div>
              <p className="font-semibold">/api/admins</p>
              <p>Manage administrator accounts.</p>
            </div>
          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Local Setup (VS Code)</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-6 text-sm text-slate-600">
            <li>Open the project folder in VS Code and install dependencies with <code>npm install</code>.</li>
            <li>Ensure .env contains Supabase credentials (already provided in this workspace).</li>
            <li>Run <code>npm run dev</code> to start the Vite frontend and Vercel serverless APIs.</li>
            <li>Login using demo credentials to explore Admin, Teacher, and Student dashboards.</li>
          </ol>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Deployment Guide</h2>
          <p className="mt-2 text-sm text-slate-600">
            Build the project with <code>npm run build</code>. Deploy the Vite app and Vercel API routes together.
            For cloud hosting, use Vercel for the API and Netlify/Render for the static frontend. Update environment
            variables for Supabase and JWT secret in the hosting dashboard.
          </p>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Screenshots Description</h2>
          <p className="mt-2 text-sm text-slate-600">
            Capture screenshots of the dashboard analytics, student management table with export buttons,
            real-time attendance log (showing status pills), and the documentation panel to showcase the ER diagram
            explanation and API list.
          </p>
        </section>
      </div>
    </div>
  );
}
