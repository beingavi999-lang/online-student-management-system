import { useEffect, useState } from 'react';
import { apiFetch, buildQuery } from '../lib/api';
import { exportToCsv } from '../lib/export';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface TeachersProps {
  token: string;
  user: any;
}

const emptyForm = {
  full_name: '',
  email: '',
  phone: '',
  department: '',
};

export default function Teachers({ token, user }: TeachersProps) {
  const [teachers, setTeachers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [form, setForm] = useState({ ...emptyForm });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState('');

  const fetchTeachers = async () => {
    setLoading(true);
    try {
      const data = await apiFetch<any[]>(
        `/api/teachers${buildQuery({ search, page, limit: 6 })}`,
        {},
        token
      );
      setTeachers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeachers();
  }, [search, page]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.full_name || !form.department) {
      setError('Name and department are required.');
      return;
    }
    try {
      if (editingId) {
        await apiFetch('/api/teachers', { method: 'PUT', body: JSON.stringify({ id: editingId, ...form }) }, token);
      } else {
        await apiFetch('/api/teachers', { method: 'POST', body: JSON.stringify(form) }, token);
      }
      setForm({ ...emptyForm });
      setEditingId(null);
      fetchTeachers();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleEdit = (teacher: any) => {
    setEditingId(teacher.id);
    setForm({
      full_name: teacher.full_name || '',
      email: teacher.email || '',
      phone: teacher.phone || '',
      department: teacher.department || '',
    });
  };

  const handleDelete = async (id: number) => {
    await apiFetch('/api/teachers', { method: 'DELETE', body: JSON.stringify({ id }) }, token);
    fetchTeachers();
  };

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Teachers" subtitle="Manage faculty records and assignments." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <input
            className="w-full max-w-sm rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Search teachers"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => exportToCsv('teachers.csv', teachers)}
            >
              Export CSV
            </button>
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => window.print()}
            >
              Export PDF
            </button>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Teacher</th>
                <th>Department</th>
                <th>Contact</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {teachers.map((teacher) => (
                <tr key={teacher.id} className="border-t border-slate-100">
                  <td className="py-3">
                    <p className="font-semibold text-slate-900">{teacher.full_name}</p>
                    <p className="text-xs text-slate-500">{teacher.email}</p>
                  </td>
                  <td>{teacher.department}</td>
                  <td className="text-slate-500">{teacher.phone}</td>
                  <td className="text-right">
                    {user.role === 'admin' ? (
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEdit(teacher)}
                          className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-semibold"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(teacher.id)}
                          className="rounded-lg border border-rose-200 px-3 py-1 text-xs font-semibold text-rose-600"
                        >
                          Delete
                        </button>
                      </div>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <button
            className="rounded-xl border border-slate-200 px-3 py-1 text-xs"
            disabled={page === 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            Previous
          </button>
          <span className="text-xs text-slate-500">Page {page}</span>
          <button
            className="rounded-xl border border-slate-200 px-3 py-1 text-xs"
            disabled={teachers.length < 6}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </button>
        </div>
      </div>

      {user.role === 'admin' && (
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900">{editingId ? 'Update teacher' : 'Add new teacher'}</h3>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Full name"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Phone"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Department"
              value={form.department}
              onChange={(e) => setForm({ ...form, department: e.target.value })}
            />
          </div>
          {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
          <div className="mt-4 flex gap-2">
            <button
              type="submit"
              className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white"
            >
              {editingId ? 'Save changes' : 'Add teacher'}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm({ ...emptyForm });
                }}
                className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
}
