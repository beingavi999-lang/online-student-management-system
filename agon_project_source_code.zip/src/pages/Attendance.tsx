import { useEffect, useMemo, useState } from 'react';
import { apiFetch, buildQuery } from '../lib/api';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';
import supabase from '../lib/supabase';

interface AttendanceProps {
  token: string;
  user: any;
}

const emptyForm = {
  student_id: '',
  course_id: '',
  date: new Date().toISOString().slice(0, 10),
  status: 'Present',
};

export default function Attendance({ token, user }: AttendanceProps) {
  const [attendance, setAttendance] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [form, setForm] = useState({ ...emptyForm });
  const [error, setError] = useState('');

  const fetchAttendance = async () => {
    setLoading(true);
    try {
      const [attendanceData, studentsData, coursesData] = await Promise.all([
        apiFetch<any[]>(`/api/attendance${buildQuery({ status: statusFilter })}`, {}, token),
        apiFetch<any[]>('/api/students', {}, token),
        apiFetch<any[]>('/api/courses', {}, token),
      ]);
      setAttendance(attendanceData);
      setStudents(studentsData);
      setCourses(coursesData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, [statusFilter]);

  useEffect(() => {
    const channel = supabase
      .channel('attendance-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'attendance' }, () => {
        fetchAttendance();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.student_id || !form.course_id) {
      setError('Student and course are required.');
      return;
    }
    try {
      await apiFetch('/api/attendance', { method: 'POST', body: JSON.stringify(form) }, token);
      setForm({ ...emptyForm });
      fetchAttendance();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUpdateStatus = async (id: number, status: string) => {
    await apiFetch('/api/attendance', { method: 'PUT', body: JSON.stringify({ id, status }) }, token);
    fetchAttendance();
  };

  const studentMap = useMemo(() => Object.fromEntries(students.map((s) => [s.id, s.full_name])), [students]);
  const courseMap = useMemo(() => Object.fromEntries(courses.map((c) => [c.id, c.name])), [courses]);

  const todaySummary = useMemo(() => {
    const today = new Date();
    const isSameDay = (date: Date) =>
      date.getFullYear() === today.getFullYear() &&
      date.getMonth() === today.getMonth() &&
      date.getDate() === today.getDate();
    const records = attendance.filter((record) => isSameDay(new Date(record.date)));
    const present = records.filter((record) => record.status === 'Present').length;
    const late = records.filter((record) => record.status === 'Late').length;
    const absent = records.filter((record) => record.status === 'Absent').length;
    const rate = records.length ? Math.round((present / records.length) * 100) : 0;
    return { total: records.length, present, late, absent, rate };
  }, [attendance]);

  const weeklySummary = useMemo(() => {
    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - 6);
    const records = attendance.filter((record) => new Date(record.date) >= weekStart);
    const present = records.filter((record) => record.status === 'Present').length;
    const late = records.filter((record) => record.status === 'Late').length;
    const absent = records.filter((record) => record.status === 'Absent').length;
    const rate = records.length ? Math.round((present / records.length) * 100) : 0;
    return { total: records.length, present, late, absent, rate };
  }, [attendance]);

  const monthlySummary = useMemo(() => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const records = attendance.filter((record) => new Date(record.date) >= monthStart);
    const present = records.filter((record) => record.status === 'Present').length;
    const late = records.filter((record) => record.status === 'Late').length;
    const absent = records.filter((record) => record.status === 'Absent').length;
    const rate = records.length ? Math.round((present / records.length) * 100) : 0;
    return { total: records.length, present, late, absent, rate };
  }, [attendance]);

  const dailyTrend = useMemo(() => {
    const days = Array.from({ length: 7 }).map((_, index) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - index));
      const label = date.toLocaleDateString(undefined, { weekday: 'short' });
      const records = attendance.filter((record) => {
        const recordDate = new Date(record.date);
        return (
          recordDate.getFullYear() === date.getFullYear() &&
          recordDate.getMonth() === date.getMonth() &&
          recordDate.getDate() === date.getDate()
        );
      });
      const present = records.filter((record) => record.status === 'Present').length;
      const rate = records.length ? Math.round((present / records.length) * 100) : 0;
      return { label, rate, total: records.length };
    });
    return days;
  }, [attendance]);

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Attendance" subtitle="Real-time attendance with WebSocket updates." />
      <div className="mb-6 grid gap-4 lg:grid-cols-3">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs uppercase text-slate-400">Daily report</p>
          <p className="mt-3 text-2xl font-semibold text-slate-900">{todaySummary.rate}%</p>
          <p className="text-sm text-slate-500">Attendance rate today</p>
          <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
            <span className="rounded-full bg-emerald-100 px-3 py-1 text-emerald-700">Present: {todaySummary.present}</span>
            <span className="rounded-full bg-amber-100 px-3 py-1 text-amber-700">Late: {todaySummary.late}</span>
            <span className="rounded-full bg-rose-100 px-3 py-1 text-rose-700">Absent: {todaySummary.absent}</span>
          </div>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs uppercase text-slate-400">Weekly report</p>
          <p className="mt-3 text-2xl font-semibold text-slate-900">{weeklySummary.rate}%</p>
          <p className="text-sm text-slate-500">Attendance rate (last 7 days)</p>
          <div className="mt-4 h-2 w-full rounded-full bg-slate-100">
            <div className="h-2 rounded-full bg-emerald-500" style={{ width: `${weeklySummary.rate}%` }} />
          </div>
          <div className="mt-3 text-xs text-slate-500">Present {weeklySummary.present} · Late {weeklySummary.late} · Absent {weeklySummary.absent}</div>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs uppercase text-slate-400">Monthly report</p>
          <p className="mt-3 text-2xl font-semibold text-slate-900">{monthlySummary.rate}%</p>
          <p className="text-sm text-slate-500">Attendance rate (current month)</p>
          <div className="mt-4 h-2 w-full rounded-full bg-slate-100">
            <div className="h-2 rounded-full bg-indigo-500" style={{ width: `${monthlySummary.rate}%` }} />
          </div>
          <div className="mt-3 text-xs text-slate-500">Present {monthlySummary.present} · Late {monthlySummary.late} · Absent {monthlySummary.absent}</div>
        </div>
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-[2fr_1fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Daily attendance trend</h2>
              <p className="text-sm text-slate-500">Last 7 days attendance rate.</p>
            </div>
            <div className="text-xs text-slate-500">Present = Emerald</div>
          </div>
          <div className="mt-6 grid grid-cols-7 gap-3">
            {dailyTrend.map((day) => (
              <div key={day.label} className="flex flex-col items-center gap-2">
                <div className="flex h-32 w-full items-end rounded-xl bg-slate-50 px-3">
                  <div
                    className="w-full rounded-lg bg-emerald-500"
                    style={{ height: `${day.rate}%` }}
                  />
                </div>
                <p className="text-xs font-semibold text-slate-600">{day.label}</p>
                <p className="text-xs text-slate-400">{day.rate}%</p>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">Status legend</h2>
          <p className="text-sm text-slate-500">Consistent color coding across reports.</p>
          <div className="mt-6 space-y-4 text-sm">
            <div className="flex items-center justify-between rounded-xl bg-emerald-50 px-4 py-3">
              <span className="font-semibold text-emerald-700">Present</span>
              <span className="text-emerald-600">On-time attendance</span>
            </div>
            <div className="flex items-center justify-between rounded-xl bg-amber-50 px-4 py-3">
              <span className="font-semibold text-amber-700">Late</span>
              <span className="text-amber-600">Late check-ins</span>
            </div>
            <div className="flex items-center justify-between rounded-xl bg-rose-50 px-4 py-3">
              <span className="font-semibold text-rose-700">Absent</span>
              <span className="text-rose-600">No attendance logged</span>
            </div>
          </div>
        </div>
      </div>
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <select
            className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="">All Statuses</option>
            <option value="Present">Present</option>
            <option value="Late">Late</option>
            <option value="Absent">Absent</option>
          </select>
          <span className="text-xs text-slate-500">Live updates enabled</span>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Student</th>
                <th>Course</th>
                <th>Date</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {attendance.map((record) => (
                <tr key={record.id} className="border-t border-slate-100">
                  <td className="py-3 font-semibold text-slate-900">{studentMap[record.student_id]}</td>
                  <td>{courseMap[record.course_id]}</td>
                  <td>{new Date(record.date).toLocaleDateString()}</td>
                  <td>
                    <span
                      className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        record.status === 'Present'
                          ? 'bg-emerald-100 text-emerald-700'
                          : record.status === 'Late'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {record.status}
                    </span>
                  </td>
                  <td className="text-right">
                    {user.role !== 'student' && (
                      <select
                        className="rounded-lg border border-slate-200 px-2 py-1 text-xs"
                        value={record.status}
                        onChange={(e) => handleUpdateStatus(record.id, e.target.value)}
                      >
                        <option value="Present">Present</option>
                        <option value="Late">Late</option>
                        <option value="Absent">Absent</option>
                      </select>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {user.role !== 'student' && (
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900">Log attendance</h3>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.student_id}
              onChange={(e) => setForm({ ...form, student_id: e.target.value })}
            >
              <option value="">Select student</option>
              {students.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.full_name}
                </option>
              ))}
            </select>
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.course_id}
              onChange={(e) => setForm({ ...form, course_id: e.target.value })}
            >
              <option value="">Select course</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name}
                </option>
              ))}
            </select>
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              type="date"
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
            />
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
            >
              <option value="Present">Present</option>
              <option value="Late">Late</option>
              <option value="Absent">Absent</option>
            </select>
          </div>
          {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
          <button type="submit" className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">
            Save attendance
          </button>
        </form>
      )}
    </div>
  );
}
