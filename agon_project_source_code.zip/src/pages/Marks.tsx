import { useEffect, useMemo, useState } from 'react';
import { apiFetch, buildQuery } from '../lib/api';
import { exportToCsv } from '../lib/export';
import Loading from '../components/Loading';
import Topbar from '../components/Topbar';

interface MarksProps {
  token: string;
  user: any;
}

const emptyForm = {
  student_id: '',
  course_id: '',
  assessment: '',
  score: '',
  max_score: '100',
};

export default function Marks({ token, user }: MarksProps) {
  const [marks, setMarks] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ ...emptyForm });
  const [error, setError] = useState('');

  const fetchMarks = async () => {
    setLoading(true);
    try {
      const [marksData, studentsData, coursesData] = await Promise.all([
        apiFetch<any[]>(`/api/marks${buildQuery({ search })}`, {}, token),
        apiFetch<any[]>('/api/students', {}, token),
        apiFetch<any[]>('/api/courses', {}, token),
      ]);
      setMarks(marksData);
      setStudents(studentsData);
      setCourses(coursesData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMarks();
  }, [search]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (!form.student_id || !form.course_id || !form.assessment) {
      setError('Student, course, and assessment are required.');
      return;
    }
    try {
      await apiFetch('/api/marks', { method: 'POST', body: JSON.stringify({
        ...form,
        score: Number(form.score || 0),
        max_score: Number(form.max_score || 100),
      }) }, token);
      setForm({ ...emptyForm });
      fetchMarks();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const studentMap = useMemo(() => Object.fromEntries(students.map((s) => [s.id, s.full_name])), [students]);
  const courseMap = useMemo(() => Object.fromEntries(courses.map((c) => [c.id, c.name])), [courses]);

  if (loading) return <Loading />;

  return (
    <div>
      <Topbar title="Marks & Results" subtitle="Track assessments, results, and academic progress." />
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <input
            className="w-full max-w-sm rounded-xl border border-slate-200 px-4 py-2 text-sm"
            placeholder="Search by assessment"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => exportToCsv('marks.csv', marks)}
            >
              Export CSV
            </button>
            <button
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold"
              onClick={() => window.print()}
            >
              Export PDF
            </button>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400">
              <tr>
                <th className="py-3">Student</th>
                <th>Course</th>
                <th>Assessment</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {marks.map((mark) => (
                <tr key={mark.id} className="border-t border-slate-100">
                  <td className="py-3 font-semibold text-slate-900">{studentMap[mark.student_id]}</td>
                  <td>{courseMap[mark.course_id]}</td>
                  <td>{mark.assessment}</td>
                  <td>
                    <span className="font-semibold text-slate-900">{mark.score}</span>
                    <span className="text-xs text-slate-500">/{mark.max_score}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {user.role !== 'student' && (
        <form onSubmit={handleSubmit} className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900">Record assessment result</h3>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.student_id}
              onChange={(e) => setForm({ ...form, student_id: e.target.value })}
            >
              <option value="">Select student</option>
              {students.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.full_name}
                </option>
              ))}
            </select>
            <select
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              value={form.course_id}
              onChange={(e) => setForm({ ...form, course_id: e.target.value })}
            >
              <option value="">Select course</option>
              {courses.map((course) => (
                <option key={course.id} value={course.id}>
                  {course.name}
                </option>
              ))}
            </select>
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Assessment name"
              value={form.assessment}
              onChange={(e) => setForm({ ...form, assessment: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Score"
              value={form.score}
              onChange={(e) => setForm({ ...form, score: e.target.value })}
            />
            <input
              className="rounded-xl border border-slate-200 px-4 py-2 text-sm"
              placeholder="Max score"
              value={form.max_score}
              onChange={(e) => setForm({ ...form, max_score: e.target.value })}
            />
          </div>
          {error ? <p className="mt-3 text-sm text-rose-500">{error}</p> : null}
          <button type="submit" className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">
            Save marks
          </button>
        </form>
      )}
    </div>
  );
}
