import { useEffect, useMemo, useState } from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  ClipboardCheck,
  ClipboardList,
  Wallet,
  FileText,
  ShieldCheck,
  ScrollText,
} from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import Teachers from './pages/Teachers';
import Courses from './pages/Courses';
import Attendance from './pages/Attendance';
import Marks from './pages/Marks';
import Fees from './pages/Fees';
import Documents from './pages/Documents';
import Docs from './pages/Docs';
import Admins from './pages/Admins';
import Login from './pages/Login';
import Loading from './components/Loading';

const navConfig = {
  admin: [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'admins', label: 'Admins', icon: ShieldCheck },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'teachers', label: 'Teachers', icon: GraduationCap },
    { id: 'courses', label: 'Courses', icon: BookOpen },
    { id: 'attendance', label: 'Attendance', icon: ClipboardCheck },
    { id: 'marks', label: 'Marks', icon: ClipboardList },
    { id: 'fees', label: 'Fees', icon: Wallet },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'docs', label: 'Documentation', icon: ScrollText },
  ],
  teacher: [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'courses', label: 'Courses', icon: BookOpen },
    { id: 'attendance', label: 'Attendance', icon: ClipboardCheck },
    { id: 'marks', label: 'Marks', icon: ClipboardList },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'docs', label: 'Documentation', icon: ScrollText },
  ],
  student: [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'attendance', label: 'Attendance', icon: ClipboardCheck },
    { id: 'marks', label: 'Marks', icon: ClipboardList },
    { id: 'fees', label: 'Fees', icon: Wallet },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'docs', label: 'Documentation', icon: ScrollText },
  ],
} as const;

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('edusphere_token') || '');
  const [user, setUser] = useState<any>(null);
  const [active, setActive] = useState('dashboard');
  const [checking, setChecking] = useState(true);

  const fetchSession = async () => {
    if (!token) {
      setChecking(false);
      return;
    }
    try {
      const res = await fetch('/api/auth', {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Invalid session');
      const data = await res.json();
      setUser(data.user);
    } catch (err) {
      setToken('');
      localStorage.removeItem('edusphere_token');
      localStorage.removeItem('edusphere_user');
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    fetchSession();
  }, [token]);

  const handleLogin = (newToken: string, newUser: any) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('edusphere_token', newToken);
    localStorage.setItem('edusphere_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setToken('');
    setUser(null);
    localStorage.removeItem('edusphere_token');
    localStorage.removeItem('edusphere_user');
  };

  const navItems = useMemo(() => {
    if (!user) return [];
    return navConfig[(user.role as keyof typeof navConfig) || 'admin'] || navConfig.admin;
  }, [user]);

  if (checking) return <Loading />;
  if (!user) return <Login onLogin={handleLogin} />;

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar items={navItems} active={active} onSelect={setActive} onLogout={handleLogout} user={user} />
      <main className="flex-1 overflow-y-auto px-6 py-8">
        {active === 'dashboard' && <Dashboard token={token} user={user} />}
        {active === 'admins' && <Admins token={token} />}
        {active === 'students' && <Students token={token} user={user} />}
        {active === 'teachers' && <Teachers token={token} user={user} />}
        {active === 'courses' && <Courses token={token} user={user} />}
        {active === 'attendance' && <Attendance token={token} user={user} />}
        {active === 'marks' && <Marks token={token} user={user} />}
        {active === 'fees' && <Fees token={token} user={user} />}
        {active === 'documents' && <Documents token={token} user={user} />}
        {active === 'docs' && <Docs />}
      </main>
    </div>
  );
}
