interface StatCardProps {
  label: string;
  value: string | number;
  change?: string;
  tone?: 'blue' | 'emerald' | 'amber' | 'purple';
}

const toneMap = {
  blue: 'from-indigo-500/15 to-indigo-500/5 text-indigo-600',
  emerald: 'from-emerald-500/15 to-emerald-500/5 text-emerald-600',
  amber: 'from-amber-500/15 to-amber-500/5 text-amber-600',
  purple: 'from-purple-500/15 to-purple-500/5 text-purple-600',
};

export default function StatCard({ label, value, change, tone = 'blue' }: StatCardProps) {
  return (
    <div className={`rounded-2xl border border-white bg-gradient-to-br ${toneMap[tone]} p-5 shadow-sm`}>
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <div className="mt-3 flex items-end justify-between">
        <p className="text-2xl font-semibold text-slate-900">{value}</p>
        {change ? <span className="text-xs font-semibold text-slate-500">{change}</span> : null}
      </div>
    </div>
  );
}
