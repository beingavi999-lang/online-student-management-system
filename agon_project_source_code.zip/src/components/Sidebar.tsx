import { LogOut } from 'lucide-react';
import React from 'react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface SidebarProps {
  items: readonly NavItem[];
  active: string;
  onSelect: (id: string) => void;
  onLogout: () => void;
  user: { full_name: string; role: string };
}

export default function Sidebar({ items, active, onSelect, onLogout, user }: SidebarProps) {
  return (
    <aside className="no-print flex h-screen w-64 flex-col border-r border-slate-200 bg-white px-4 py-6">
      <div className="px-2">
        <div className="flex items-center gap-2 text-xl font-semibold text-slate-900">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white">ES</div>
          EduSphere
        </div>
        <p className="mt-2 text-xs uppercase tracking-wide text-slate-400">{user.role} portal</p>
        <p className="text-sm font-medium text-slate-700">{user.full_name}</p>
      </div>
      <nav className="mt-8 flex-1 space-y-1">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onSelect(item.id)}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm font-medium transition ${
                active === item.id
                  ? 'bg-indigo-50 text-indigo-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </button>
          );
        })}
      </nav>
      <button
        onClick={onLogout}
        className="mt-4 flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-slate-500 hover:bg-slate-100"
      >
        <LogOut className="h-4 w-4" />
        Sign out
      </button>
    </aside>
  );
}
